Dans cet exercice, nous allons utiliser une technique de hacker pour retrouver un mot de passe inconnu
